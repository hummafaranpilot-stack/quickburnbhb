<!DOCTYPE html>
<html>
<head>
	<title>Simple Promise&#8482;</title>
    <meta property="og:url" name="url" content="https://cb.venoplus8.com/aff/">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<meta charset="utf-8">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<!-- disable auto telephone linking in iOS -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,400;1,400;1,700&family=Montserrat:ital,wght@0,400;0,500;0,600;0,800;1,400;1,500;1,600;1,800&display=swap" rel="stylesheet">
	<!-- <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet"> -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

	<link href="https://cdn.truegcloud.com/scripts/skeleton.min.css" rel="stylesheet">
	<link href="https://cdn.truegcloud.com/scripts/all.min.css" rel="stylesheet">


	
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KMZ74FC');</script>
<!-- End Google Tag Manager -->
<script>
  
  

  </script>


<!-- jQuery 1.7.2+ or Zepto.js 1.0+ -->
<script src="https://cdn.truegcloud.com/scripts/jquery.1.9.1.min.js"></script>

<!-- Start Visual Website Optimizer Synchronous Code -->
<script type='text/javascript'>
    var _vis_opt_account_id = 407590;
    var _vis_opt_protocol = (('https:' == document.location.protocol) ? 'https://' : 'http://');
    document.write('<s' + 'cript src="' + _vis_opt_protocol +
        'dev.visualwebsiteoptimizer.com/deploy/js_visitor_settings.php?v=1&a=' + _vis_opt_account_id + '&url=' + encodeURIComponent(document.URL) + '&random=' + Math.random() + '" type="text/javascript">' + '<\/s' + 'cript>');
</script>

<script type='text/javascript'>
    if (typeof(_vis_opt_settings_loaded) == "boolean") {
        document.write('<s' + 'cript src="' + _vis_opt_protocol +
            'd5phz18u4wuww.cloudfront.net/vis_opt.js" type="text/javascript">' + '<\/s' + 'cript>');
    }
    // if your site already has jQuery 1.4.2, replace vis_opt.js with vis_opt_no_jquery.js above
</script>

<script type='text/javascript'>
    if (typeof(_vis_opt_settings_loaded) == "boolean" && typeof(_vis_opt_top_initialize) == "function") {
        _vis_opt_top_initialize();
        vwo_$(document).ready(function() {
            _vis_opt_bottom_initialize();
        });
    }
</script>
<!-- End Visual Website Optimizer Synchronous Code -->

<!-- Start Clarity Script -->
<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "ubz7g4sl1y");
</script>
<!-- End Clarity Script -->

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '');
  fbq('init', '');
  fbq('track', 'PageView');
  fbq('track', 'ViewContent');
  setTimeout(function(){
  fbq("track",'20Min');
  }, 1200000);
  setTimeout(function(){
  fbq("track",'10Min');
  }, 600000);
  setTimeout(function(){
  fbq("track",'25Min');
  }, 1500000);
  setTimeout(function(){
  fbq("track",'30Min');
  }, 1800000);
</script>
<noscript>
  <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1" />
  <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1" />
</noscript>
<!-- End Facebook Pixel Code -->

<script type="text/javascript">
    function hideGreyHead() {
      document.getElementById("greyhead").style.display = "none";
    }
	function showBuyLink() {
	  document.getElementById("buylink").style.display = "block";
	}
        // adjust this as needed, 1 sec = 1000
    setTimeout("hideGreyHead()", 15000);
	setTimeout("showBuyLink()", 5000);
</script>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<meta name="robots" content="noindex">

<title>Simple Promise&#8482;</title>

<link href="../css/skeleton.min.css" rel="stylesheet">
<link href="../css/all.min.css" rel="stylesheet">
<link href="../css/fontawesome.min.css" rel="stylesheet">
<link href="../css/regular.min.css" rel="stylesheet">
<link href="../css/solid.min.css" rel="stylesheet">
<link href="../css/brands.min.css" rel="stylesheet">
<link href="../css/main.css" rel="stylesheet">
<link href="../css/atc.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i|Montserrat:400,400i,600,600i,700,700i,800,800i&display=swap" rel="stylesheet">

<!-- Header Logo
<nav class="fixed-top">
	<img src="https://cdn.truegcloud.com/simplepromise/SP-Logo-Hanging.png" alt="" class="d-none d-md-block">
</nav>-->

<!-- Call Reveal
<div id="menu-bar">
	<div class="handle">
		<img src="https://cdn.truegcloud.com/cyabags/5thglow-phone-inverted.svg" alt="" width="25" height="25">
	</div>
	<h6>
		1-800-259-9522<br/>
		<small><i class="fas fa-chevron-left"></i> Press <kbd>ESC</kbd> to close</small>
	  </h6>
</div>-->

<!-- ClickBank Trust Badge -->
<script src='//cbtb.clickbank.net/?vendor=xitox'></script>

<!-- Start Lucky Orange Script -->
<!-- <script type='text/javascript'>
window.__lo_site_id = 329229;

	(function() {
		var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
		wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
	  })();
</script> -->
<!-- End Lucky Orange Script -->	<!-- Additional CSS Goes Here -->
	<link href="../css/landerstyle.css" rel="stylesheet" />
	 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/affstyle.css">
<link rel="stylesheet" type="text/css" href="../css/affstyle-new.css">

   <style>
        span.spinner-border.spinner-border-sm {
            width: 23px ;
            height: 23px;
        }
   </style> 


    <script>
      window.__app = {
        visit_id: undefined,
        query: Object.freeze(window.location.search.substr(1).split(/&+/).reduce(function(map,c) {
          var a = c.match(/([^=]+)=(.*)/) || []
          if (a[1]) {
            map[a[1]] = a[2]
          }
          return map
        }, {})),
        cookies: Object.freeze(document.cookie.split(/;\s+/).reduce(function(map,c) {
          var a = c.match(/([^=]+)=(.*)/) || []
          if (a[1]) {
            map[a[1]] = a[2]
          }
          return map
        }, {})),
      }
    </script>

    <script defer async>
          (function(script) {
            script.src = "//" + location.hostname
              + "/api/visits?page_id=47&page_version=&request_id=C7B89269%3AB12A_D197C0D8%3A01BB_64545C53_1ABB2D%3A1826AE"
              + "&querystring=" + encodeURIComponent(window.location.search.substr(1))
              + "&fbclid=" + encodeURIComponent(__app.query.fbclid || "")
              + "&fbp=" + encodeURIComponent(__app.cookies._fbp || "")
              + "&fbc=" + encodeURIComponent(__app.cookies._fbc || "")
              + "&referrer=" + encodeURIComponent(document.referrer);
            document.head.appendChild(script);
          })(document.createElement("script"));
        </script>

        <script>
          function recordEmailConversion(email) {
            return new Promise(function(resolve, reject) {

              const url = "//"
                + location.hostname
                + "/api/conversions/email-collected"
                + location.search

              const xhr = new XMLHttpRequest

              xhr.onreadystatechange = function() {

                if (xhr.readyState !== XMLHttpRequest.DONE) {
                  return
                }

                if (Math.floor(xhr.status / 100) !== 2) {
                  return reject(xhr.responseText || "Network Error")
                }

                try {
                  var response = JSON.parse(xhr.responseText)
                }
                catch (error) {
                  return reject("Failed parsing server response: " + error.toString())
                }

                resolve(response)
              }

              xhr.onerror = reject

              xhr.open("POST", url)
              xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8")

              xhr.send(JSON.stringify({
                email,
                page_id: 47,
                page_version: "" || undefined,
                referrer: document.referrer,
                request_id: "C7B89269:B12A_D197C0D8:01BB_64545C53_1ABB2D:1826AE" || undefined,
              }))
            })
          }
    </script>
</head>

<body>

  	<div class="page-wrapper">
            <header style="height: 100%;">
            <div class="header-banner-wrapper">

                <span class="banner-logo">
                    <img src="https://simplepromise.com/cdn/shop/files/logo_352x.png?v=1613178340" alt="viva-logo">
                </span>

                <div class="banner-line"></div>

            </div>

            <div class="top-heading">
                <h1 class="text-blue">MONSTER OFFER <br class="br-xr br-14pm">VenoPlus 8<sup class="tm">TM</sup>!</h1>
				<h3>is going to supercharge <br class="br-se br-14pm br-12p br-xr">your commissions!
</h3>
            </div>


				<section id="prod-description" class="pt-1 pt-md-3 pb-4 pb-lg-5">
		<div class="container">
			<div class="col-12 col-lg-11 mx-auto">
				<div class="row align-items-center">
					<div class="col-12 col-lg-6">
						<!--<img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/ovunashop/img/ovuna.png" class="img-fluid">-->
						<picture class="img-fluid">
                           <source class="" srcset="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/bottle-mention02.webp" type="image/webp">
                            <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/bottle-mention02.png" class="img-fluid" alt="">
                        </picture>
					</div>
						<div class="col-12 col-lg-6 col-md-10 mx-auto prod-description px-1 px-md-3 my-auto">
					      <ul class="text-left my-lg-4 col-12 col-md-10 mx-auto pl-4 pl-md-0 new-list">
            <li class="mb-2 mb-lg-4 pb-md-2">Massive payouts - <strong>60% initial sales+ 20% upsells </strong>(over EPC $2+)</li>
            <li class="mb-2 mb-lg-4 pb-md-2"> Heart health & nitric oxide supplement - converts well with a wide audience base
</p></li>
            <li class="mb-2 mb-lg-4 pb-md-2">Constantly optimized swipes & landers to ensure best conversions</li>


          </ul>
			</div>






				</div>
			</div>
		</div>
	</section>


        </header>

        <main>
            <div class="inner-wrapper py-2">
                <div class="top-banner-red-links">
                    <span>Offer Information <span class="slash">|</span></span>
                    <a href="#traffic-tips">Traffic Tips <span class="slash">|</span></a>
					 <a href="#affiliate-link">Affiliate Link <span class="slash">|</span></a>
                    <a href="#promotion-terms">Promotion Terms <span class="slash">|</span></a>
					<br class="d-md-block d-none"><a href="#email-swipes">Email Swipes <span class="slash">|</span></a>
                    <a href="#product-images">Product Images <span class="slash">|</span></a>
					<a href="#ad-images">Ad Images <span class="slash">|</span></a>
                    <a href="#install-pixels">Install Pixel <span class="slash">|</span></a>
                    <a href="#contact-us">Contact Us </a>
                </div>

                <section class="container-md first-section section-paragraphs">
                    <h3 class="section-header section-header-2">Offer Information<span></span></h3>
                      <div class="row">
                        <div class="col-12 col-md-10 mx-auto">

                    <!-- <p>Xitox's™ foot pad provides a natural way to help you unwind and promote skin health on your feet. These foot pads can be easily applied, allowing you to feel more refreshed and rejuvenated.</p>-->

               <p>
VenoPlus 8™ is a powder supplement designed to support healthy blood pressure and cholesterol levels.
</p>
               <p>Backed by scientific studies, here’s how <br class="br-se br-12p">VenoPlus 8™ safeguards your heart health: </p>

               <ul class="list-wrapper text-left mt-4 mt-md-0 mb-4 col-12 col-md-10 mx-auto pl-4 pl-md-5">
            <li class="mb-2 mb-md-3 font-weight-bold"><i class=" icon material-icons">check</i> <p>Increases nitric oxide to support heart health
</p></li>
            <li class="mb-2 mb-md-3 font-weight-bold"><i class=" icon material-icons">check</i> <p>Boosts blood flow for better circulation
</p></li>
            <li class="mb-2 mb-md-3 font-weight-bold"><i class=" icon material-icons">check</i> <p>Eliminates excess plaque for clearer arteries
</p></li>
            <li class=" mb-0font-weight-bold"><i class=" icon material-icons">check</i> <p class="mb-0">Balances cholesterol and blood pressure levels
</p></li>

          </ul>
					</div>
			</div>
				</section>




				  <section class="container-md first-section section-paragraphs">

							<h2 class="text-center text-blue"><object data="https://cdn.truegcloud.com/ovunashop/img/verified.svg" type="image/svg+xml" class="mob-only align-middle">
							<img src="https://cdn.truegcloud.com/ovunashop/img/verified.svg" />
						</object>
						Thousands of People Have <br class="d-md-block d-none">Achieved <br class="br-se">Amazing Results
						<object data="https://cdn.truegcloud.com/ovunashop/img/verified.svg" type="image/svg+xml" class="desk-only align-middle">
							<img src="https://cdn.truegcloud.com/ovunashop/img/verified.svg" />
						</object></h2>
					    <div class="row">
                        <div class="col-12 col-md-11 mx-auto">



								<div  id="reviews" class="d-none d-lg-block">
<!--start of testimonial-->
<div class="row justify-content-center" >
	<div class="col-12 col-md-2">
		<div class="mb-lg-3">
			<img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-09.png" class="img-fluid rounded-circle d-block mx-auto w-75">
		</div>
		<h4 class="name">Nancy</h4>
		<div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
		<div class="verified-green"><i class="fas fa-check mr-1"></i>Verified Buyer</div>
	</div>
	<div class="col-12 col-md-7 align-self-center">
		<h4 style="text-align: left">“My blood pressure is finally stable.”</h4>
		<p>“I've used this for several months now and they have helped keep my blood pressure in an acceptable range.”<sup>†</sup></p>
	</div>
</div>
<!--end of testimonial-->
<hr>
<!--start of testimonial-->
<div class="row justify-content-center" >
	<div class="col-12 col-md-2">
		<div class="mb-lg-3">
			<img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-10.png" class="img-fluid rounded-circle d-block mx-auto w-75">
		</div>
		<h4 class="name">Randy</h4>
		<div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
		<div class="verified-green"><i class="fas fa-check mr-1"></i>Verified Buyer</div>
	</div>
	<div class="col-12 col-md-7 align-self-center">
		<h4 style="text-align: left">“It is now my daily routine.”</h4>
		<p>“I’ve taken this for 3 months and my doctor is finally off my case. I enjoy taking this daily. It give me peace of mind.”<sup>†</sup></p>
	</div>
</div>
<!--end of testimonial-->
<hr>
<!--start of testimonial-->
<div class="row justify-content-center" >
	<div class="col-12 col-md-2  align-self-center">
		<div class="mb-lg-3">
			<img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-11.png" class="img-fluid rounded-circle d-block mx-auto w-75">
		</div>
		<h4 class="name">Rick</h4>
		<div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
		<div class="verified-green"><i class="fas fa-check mr-1"></i>Verified Buyer</div>
	</div>
	<div class="col-12 col-md-7 align-self-center">
		<h4 style="text-align: left">“Taste great and gives me the energy I missed<br class="d-none d-lg-block"> years ago!”</h4>
		<p>“I’ve known beets can help with blood flow for a while. But I’ve never liked the taste of beets. Although, this drink tastes delicious. I normally have it every day around 3 pm as a little treat. It gives me energy. And I know I’m taking care of my heart in the process. I don’t see myself giving this up. This will be as regular as having a cup of coffee in the morning.”<sup>†</sup></p>
	</div>
</div>
<!--end of testimonial-->

</div>			<style type="text/css">
	.carousel-control-prev-icon {
 background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23333' viewBox='0 0 8 8'%3E%3Cpath d='M5.25 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E") !important;
}

.carousel-control-next-icon {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23333' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E") !important;
}

.carousel-control-next, .carousel-control-prev {
background: none;
border: none;
top: 40px;
bottom: unset;
}
.carousel-item{
	padding-bottom: 15px;	
}
.carousel-item h4{
	margin-top: 10px;	
}
</style>

<div id="carouselExampleControls" class="carousel slide d-md-block d-lg-none" data-ride="carousel">
  <div class="carousel-inner" id="reviews">
    <div class="carousel-item active" data-interval="7000">
      <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-09.png" class="img-fluid rounded-circle d-block mx-auto" width="150">
		<h4>“My blood pressure is <br class="d-block d-md-none">finally stable.”</h4>
		<p>“I've used this for several months now and they have helped keep my blood pressure in an acceptable range.”<sup>†</sup></p>
		<h4 class="name">Nancy</h4>
		<div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
		<div class="verified-green"><i class="fas fa-check mr-1"></i>Verified Buyer</div>
    </div>
    <div class="carousel-item">
       <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-10.png" class="img-fluid rounded-circle d-block mx-auto" width="150">
		<h4>“It is now my daily routine.”</h4>
		<p>“I’ve taken this for 3 months and my doctor is finally off my case. I enjoy taking this daily. It give me peace of mind.”<sup>†</sup></p>
      <h4 class="name">Randy</h4>
		<div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
		<div class="verified-green"><i class="fas fa-check mr-1"></i>Verified Buyer</div>
    </div>
    <div class="carousel-item">
      <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-11.png" class="img-fluid rounded-circle d-block mx-auto" width="150">
		<h4>“Taste great and gives me the energy I missed years ago!”</h4>
		<p>“I’ve known beets can help with blood flow for a while. But I’ve never liked the taste of beets. Although, this drink tastes delicious. I normally have it every day around 3 pm as a little treat. It gives me energy. And I know I’m taking care of my heart in the process. I don’t see myself giving this up. This will be as regular as having a cup of coffee in the morning.”<sup>†</sup></p>
      <h4 class="name">Rick</h4>
		<div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
		<div class="verified-green"><i class="fas fa-check mr-1"></i>Verified Buyer</div>
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-target="#carouselExampleControls" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselExampleControls" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </button>
</div>

		 </div></div></section>
			<section class="pb-3">
			<div class="container ">

				<div class="row py-2 p-md-4 px-0" id="headline" >
					<div  class="col-12 col-lg-10 col-md-8 mx-auto text-center mt-0" id="ingredients">
						<h2 class="text-center ">Inside Every <br class="br-xr br-12p br-14pm">VenoPlus 8<sup>™</sup> <br class="br-se br-12p br-xr br-14pm">You’ll Find…</h2>
					</div>
				</div>





				  <div class="row"  id="ingredients-section">
                        <div class="col-12 col-md-10 mx-auto">


<div class="row mb-md-3">
	<div class="d-flex flex-wrap justify-content-xl-12-around mx-auto">
		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/MenaQ7-0.png " alt="">
			</picture>

			<h4 class=" text-center mb-md-0 mb-3">#1: <br class="d-md-block d-none">MenaQ7®</h4>
		  </div>

		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-03.jpg" alt="">
			</picture>

				<h4 class=" text-center mb-md-0 mb-3">#2: <br class="d-md-block d-none">RedNite®</h4>
		</div>

		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/ecomm-sl/vp8-ecomm-04.jpg" alt="">
			</picture>

				<h4 class=" text-center mb-md-0 mb-3">#3: <br class="d-md-block d-none">Pomella®</h4>
		</div>
		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/magnesium.jpg" alt="">
			</picture>

				<h4 class=" text-center mb-md-0">#4: <br class="d-md-block d-none">Magnesium</h4>
		</div>
	</div>
</div>

<div class="row mb-md-3">
	<div class="d-flex flex-wrap justify-content-center mx-auto">
		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://cdn.truegcloud.com/venoplus8/images/fe/Hesperidin.jpg" alt="">
			</picture>

			<h4 class="text-center mb-md-0 mb-3">#5: <br class="d-md-block d-none">Hesperidin</h4>
		  </div>

		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/L-citrulline.jpg" alt="">
			</picture>

				<h4 class="text-center mb-md-0 mb-3">#6: <br class="d-md-block d-none">L-citrulline</h4>
		</div>

		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/L-arginine.jpg" alt="">
			</picture>

				<h4 class=" text-center mb-md-0 mb-3">#7: <br class="d-md-block d-none">L-arginine</h4>
		</div>
		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/L-taurine.jpg" alt="">
			</picture>

				<h4 class="text-center mb-md-0 mb-3">#8: <br class="d-md-block d-none">L-taurine</h4>
		</div>

	</div>
</div>

	<div class="row mb-md-3">
	<div class="d-flex flex-wrap justify-content-center mx-auto">
		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/Vitamin%20C.jpg" alt="">
			</picture>

			<h4 class="text-center mb-md-0 mb-3">#9: <br class="d-md-block d-none">Vitamin C</h4>
		  </div>

		<div class="px-4 pb-3 col-lg-3 col-md-3 text-center">
			<picture class="img-fluid mt-md-2 mt-0 mb-3">

				<img class="img-fluid mt-md-2 mt-0 mb-3 w-50-new rounded-circle text-center mx-auto" src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/aff/grapeseedoil-2.jpg" alt="">
			</picture>

				<h4 class="text-center mb-md-0 mb-3">#10: <br class="d-md-block d-none">Grape Seed Extract</h4>
		</div>



	</div>
</div>





					  </div></div>






													</div>
												</section>









            <section id="affreason">
                <div class="container">
                    <div class="row justify-content-center mb-4">
                        <div class="col-12 col-lg-9 col-md-10 mx-auto">
                            <div class="bg-bright py-4 px-5">
                              <h2 class="text-center text-blue" id="traffic-tips">Traffic Tips</h2>
                                <p>Affiliates promoting VenoPlus 8™  will earn <strong>60% on initial sales + 20% on upsells</strong> (over EPC $2+!!!)</p>
          <p>We have made the best conversions among people who are: </p>
                                <ul class="new-list my-0 py-0 px-0 px-lg-4 mx-lg-4 mx-0">
                                    <li class="mb-md-4">Concerned about their heart health </li>
                                     <li class="mb-md-4">Boost nitric oxide levels in their bodies </li>
                                     <li class="mb-md-4">Having cardiovascular health issues </li>
                                    <li class="mb-md-4">In need to improve their blood pressure and cholesterol level </li>
                                    <li class="mb-md-4">Looking for supplements for their general well-being </li>
                                     <li class="mb-md-4">Age groups above 40 years old </li>
                                     <li class="mb-md-4">Top converting markets: USA, Canada </li>
                                </ul>

                            </div>
                        </div>
                    </div>


                </div>
            </section>
                <!--<section class="container-md second-section center-paragraph section-banners section-paragraphs">
                    <div class="section-banner banner-bg">
                        <p>“I have been taking Vivaslim for several months and my in-between meal snacking has stopped. I find myself eating less at meals”</p>
                        <span class="author">- Jimmy Mack Hunter</span>
                    </div>
                    <div class="section-banner banner-bg">
                        <p>
                            “I have been using Visaslim as part of my vitamins and dieting and I have lost 8lbs in 2 weeks. So far so good. Thank you.”
                        </p>
                        <span class="author">- Steven Gersten</span>
                    </div>
                    <div class="section-banner banner-bg">
                        <p>“The oil (10 drops in water) 3 times a day and I have lost my voracious appetite. I have dropped weight and am starting to look like I did when I was 30. Yeah.”</p>
                        <span class="author">- LaRue Hundemer-Jones</span>
                    </div>
                    <div class="section-banner banner-bg">
                        <p>
                            “This really works! I lost 4 kgs in 2 weeks which is a lot for me. I couldn’t believe my eyes when I saw the scales! I’ve recommended this product to friends &amp; family and they all can’t wait to start taking them. Had to give them bottles from my second order which I just received! Obviously I’ll keep taking these drops myself as I'm blown away by the results!”
                        </p>
                        <span class="author">- Charmaine</span>
                    </div>
                </section>-->
                <section class="container-md third-section text-section affiliate-sections mt-3" >
                    <h3 id="affiliate-link" class="section-header affiliate-header">Affiliate Link</h3>
<!--<div class="col-12 col-md-9 mx-auto border border-danger  p-5" id="affiliatelink">
            <p class="font-weight-bold text-left">Please contact us at <a href="mailto:cb.xitox.affhelp@truegenics.com?subject=RE: Xitox Clickbank Offer" class="black">cb.xitox.affhelp@truegenics.com</a> to request for permission. We will send your link over upon receiving your request.</p>
                </div>-->
                     <div class="affiliate-bg">
                        <div class="affiliate-dotted p-4 ">
                         <h4>How to get started</h4>
                            <ul>
                                <li><i class=" icon material-icons blue">check</i>Sign up with an account at Clickbank.com</li>
                                <li><i class=" icon material-icons blue">check</i>Replace xxxx with your own Clickbank affiliate ID or nickname.</li>
                                <li><i class=" icon material-icons blue">check</i>Insert your own tracking reference following the TID = value (optional)</li>
                            </ul>
                        </div>
                    </div>
                </section>
                <section class="container-md affiliate-form section-banner">
                    <div class="affiliate-border">
                        <form>
                            <div class="mb-3">
                                <label for="name" class="form-label">Your Name:</label>
                                <input type="text" class="form-control" id="name" placeholder="Enter your Name">
                                <span id="name-error-message" style="color: #AD231B;"></span>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Your Email:</label>
                                <input type="email" class="form-control" id="email" placeholder="Enter your Email">
                                <span id="email-error-message" style="color: #AD231B;"></span>
                            </div>
                            <div class="mb-3">
                                <label for="ClickbankId" class="form-label">Your Clickbank ID:</label>
                                <input type="text" class="form-control" id="affiliateId" placeholder="Enter your Clickbank ID">
                                 <span id="affiliate-error-message" style="color: #AD231B;"></span>
                             </div>
                            <div class="mb-3">
                                <label for="TrackingId" class="form-label">Tracking ID:</label>
                                <input type="text" class="form-control" id="trackingId" placeholder="Enter your Tracking ID">
                            </div>
                            <div class="mb-3">
                                <label for="landingPage" class="form-label">Landing Page:</label>
                                <select class="form-select" aria-label="Default select example" id="landingPage">
                                   <option value="fe">🔥Most optimized - VSL (with exit popup)🔥</option>
                                   <option value="fenopopup">🔥Most optimized VSL (no exit popup) 🔥</option>
                                    <option value="fesl">✨Text Sales Letter ✨</option>
                                    <option value="purchase">✨Direct to Checkout✨</option>
                                </select>
                            </div>
                              <button type="submit" class="btn btn-primary submit" id="submit">
                                <div class="spinner-box" style="display: none; margin: 0px 21px">
                                    <span class="spinner-border spinner-border-sm"></span>
                                    <!-- <span class="spinner-text">Loading..</span> -->
                                </div>
                                
                                <span class="btn-text">Submit</span>
                            </button>
                           
                              <div class="mb-3">
                                <input type="text" class="form-control" id="SSLHopLink" placeholder="https://hop.clickbank.net/?affiliate=XXXX&amp;vendor=venoplus8">
                            </div>

                  <div class="tooltip-wrap">
                      <button class="btn btn-danger btn-lg fw-bold copy" id="copy" style="position: relative;"><span class="tooltiptext" id="myTooltip" style="display: none;">Copied</span> COPY</button>
                  </div>
                            <h6 class="text-danger">*Do test your links in incognito mode.</h6>

                        </form>
                    </div>
                </section>


                <section class="container-md fifth-section agreement-section">
                    <h3 class="section-header" id="promotion-terms">Read Our Terms & Conditions <br class="br-14pm br-12p br-xr br-se">Before Promoting</h3>
                    <div class="row">
                        <div class="col-12 col-md-9 mx-auto">
                    <p class="font-weight-bold text-danger">ANY AFFILIATE CAUGHT BREAKING ANY OF THESE TERMS WILL BE IMMEDIATELY BANNED, AND WILL NOT BE ELIGIBLE FOR REINSTATEMENT.
</p>
                    <ol>
                        <li>Affiliates are not permitted to use any terminology in ads or landing pages that are considered non-compliant by the FTC or FDA. Affiliates must be in compliance with all applicable laws, regulations, and guidelines, including without limitation the Federal Trade Commission Act (“FTC Act”).
</li>
                        <li>Affiliates CANNOT use ANY before/after photos that belong to VenoPlus 8™ in their online promotions.
 </li>
                        <li>Affiliates CANNOT run any PPC and keyword search campaign on search engine platforms.


</li>
                        <li>Affiliates must not use terms such as “scam” and “fraud” in their online promotions about VenoPlus 8™.
</li>
                        <li>Affiliates must not use spam to promote VenoPlus 8™.
</li>
                        <li>Affiliates are forbidden from creating webpages, social media pages or accounts that falsely represent themselves as the creators or owners of VenoPlus 8™.
</li>
                        <li>Affiliates are not authorized to collect payments or sell any VenoPlus 8™ products from other websites as a "reseller". Affiliates are not authorized to sell products claiming to be <br class="br-12p">VenoPlus 8™, or promoting <br class="br-se br-xr">VenoPlus 8™ on retail sites such as eBay, Amazon, or any sites that fall into the category of retail sites.
</li>
                        <li>VenoPlus 8™ team will be solely responsible for all customer service enquiries.
</li>

                    </ol>
                    </div>
                </div>
                </section>
                <section class="container-md swipes-section">
                    <h3 id="email-swipes" class="section-header email-swipes">Top Email Swipes</h3>
                      <div class="row">
                        <div class="col-12 col-md-9 mx-auto">
                    <p> Our swipes are constantly refreshed for highest performance.</p>
                    <p><a href="https://docs.google.com/document/d/11iIqOdyjgm-116NEjKzo7MSUCwm_KsP7JAabeBljA-E/edit#heading=h.uv7voheg92iv" target="”_blank”">Click here</a> to access our tested and proven swipes </p>
                    <p>Note: You are only allowed to promote to opted-in subscribers. No spamming is allowed. You will be blacklisted immediately if you send unsolicited emails.</p>
                </div> </div>
                </section>
                 <section class="container-md">
                    <h3 id="product-images" class="section-header">Product Images</h3>
                      <div class="row">
                        <div class="col-12 col-md-9 mx-auto">
                    <p>Here are the product images you can use in your promotions. You MUST NOT use any other product images without prior written permissions from us.</p>
                    <p>To save these images to your computer: Right click the image and select “Open image in new tab” > right-click the image and select "Save Image As".</p>
                </div>
                    <div class="row my-3 justify-content-center text-center mx-auto">
                        <div class="col-12 col-md-4 mb-lg-0 mb-4">
                            <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/venoplus8-slider-1.png" class="img-fluid">
                        </div>
                        <div class="col-12 col-md-4 mb-lg-0 mb-4">
                            <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/venoplus8-slider-2.png" class="img-fluid">
                        </div>
                        <div class="col-12 col-md-4">
                            <img  src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/fe/venoplus8-slider-3.png" class="img-fluid">
                        </div>
                    </div></div>
                </section>


				   <section class="container-md">
                    <h3 id="ad-images" class="section-header">Campaign Images</h3>
                      <div class="row">
                        <div class="col-12 col-md-9 mx-auto">
							  <p>Here are the product images you can use in your promotions. You MUST NOT use any other product images without prior written permissions from us.</p>
                    <p>To download these images: Right click the image and select “Open image in new tab” > right-click the image and select "Save Image As".
</p>
                </div>
                    <div class="row my-3 justify-content-center text-center mx-auto">
                        <div class="col-12 col-md-4 mb-lg-0 mb-4">
                            <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/aff/p2.jpg" class="img-fluid">
                        </div>
                        <div class="col-12 col-md-4">
                            <img src="https://tgenics-cdn.s3.ap-southeast-1.amazonaws.com/venoplus8/images/aff/P3.png" class="img-fluid">
                        </div>

                    </div></div>
                </section>







				<section class="container-md product-images-section">
                    <h3 id="install-pixels" class="section-header email-swipes">Install Pixel</h3>
                      <div class="row">
                        <div class="col-12 col-md-9 mx-auto">
                    <p class="font-weight-bold">You can place your pixels by using Clickbank’s integrated tracking feature. No waiting around or troubleshooting pixels when they don’t fire!

</p>
							<p>Follow the Clickbank guide below to place your own tracking pixels of any kind:
</p>
                    <p><a href="https://support.clickbank.com/hc/en-us/articles/220375827" class="red-links">https://support.clickbank.com/hc/en-us/articles/220375827</a>                </p>
                        </div>
            </div>
                </section>
                 <section class="container-md contact-section">
                    <h3 id="contact-us" class="section-header email-swipes">Contact Us</h3>
                   <div class="row">
                      <div class="col-12 col-md-9 mx-auto">
                    <p>Please contact us at
                      <span class="black"><a href="mailto:cb.venoplus8.affhelp@truegenics.com?subject=RE: VenoPlus8 Clickbank Offer" class="black">cb.venoplus8.affhelp@truegenics.com</a></span>                </p>
                     </div>
            </div>
                </section>
            </div>
        </main>


        <footer id="main-footer" class="text-white py-5">
	<div class="container">
		<div class="row">
			<div class="col-lg-2">
				<img src="https://cdn.truegcloud.com/nutonen/footer-logo.png" alt="" class="img-fluid mb-4">
			</div>
			<div class="col-lg-4 order-lg-2">
				<h6 class="mb-3">Contact Information</h6>
				<!--<div class="row">
					<div class="col-12">
						<p class="address"><img src="https://cdn.truegcloud.com/nutonen/icon-location1.svg" alt="" class="mr-2 d-lg-none" width="20"> 3242 NE 3rd Avenue #1051 Camas, WA 98607</p>
					</div>
				</div>-->
				<div class="row">
					<div class="col-12">
						<p class="mail"><img src="https://cdn.truegcloud.com/nutonen/icon-mail1.svg" alt="" class="mr-2 d-lg-none" width="28"> For Product Support, please contact us <a href="http://help.simplepromise.com/support/tickets/new" class="text-yellow">here</a> or call 1-800-259-9522</p>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<p class="mail"><img src="https://cdn.truegcloud.com/nutonen/icon-mail1.svg" alt="" class="mr-2 d-lg-none" width="28"> For Order Support, please contact ClickBank <a href="https://www.clkbank.com/#!/" class="text-yellow">here</a> or 1-800-390-6035</p>
					</div>
				</div>
			</div>
			<div class="col-lg-6 order-lg-1">
				<h6>Disclaimer</h6>

				<p>* These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease. Please Note: The material on this site is provided for informational purposes only and is not medical advice. Always consult your physician before beginning any diet or exercise program.</p>
				<p>† Testimonials within our advertisement are real life reactions of real customer at Simple Promise™; however their name has been changed for privacy. Individual results may vary.</p>
				<p style="text-indent: 0px !important;">ClickBank is the retailer of products on this site. CLICKBANK® is a registered trademark of Click Sales Inc., a Delaware corporation located at 1444 S. Entertainment Ave., Suite 410 Boise, ID 83709, USA and used by permission. ClickBank's role as retailer does not constitute an endorsement, approval or review of these products or any claim, statement or opinion used in promotion of these products.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<ul>
					<li><a href="https://support.simplepromise.com/">FAQ</a></li>
					<li><a href="https://simplepromise.com/pages/shipping-return-policy-cb">Shipping & Refund Policy</a></li>
					<li><a href="https://simplepromise.com/pages/privacy-policies">Privacy Policy</a></li>
					<li><a href="https://simplepromise.com/pages/terms-disclaimer">Terms & Disclaimer</a></li>
				</ul>
			</div>
			<div class="col-md-12">
				<p class="text-center text-uppercase mb-0">Copyright &copy; 2019 &#8211; 2026 SIMPLE PROMISE&#8482;. ALL RIGHTS RESERVED.</p>
			</div>
		</div>
	</div>
</footer>

<script src="../css/loader/loader.js"></script>

<!-- DO NOT DELETE THIS SCRIPTS -->
<script src="../js/jquery.min.js"></script>
<script src="../js/skeleton.bundle.min.js"></script>
<script src="../js/slidereveal.js"></script>
<script>
	$(function() {
		var slider = $("#menu-bar").slideReveal({
			// width: 100,
			push: false,
			position: "right",
			// speed: 600,
			trigger: $(".handle"),
			// autoEscape: false,
		});
	});
</script>
<!-- Additional Javascripts Goes Here -->
  </div>
      <script src="https://cdn.truegcloud.com/scripts/jquery.1.9.1.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>

<script defer async>
      document.addEventListener("DOMContentLoaded", function() {

        const augmentedPaymentLinks = [["venoplus8.pay.clickbank.net",{"user_id":"__user_id","page_id":"__page_id","page_version":"__page_version","hostname":"__hostname"}]]
          .sort(function(a,b) { return b[0].length - a[0].length })
          .map(function(entry) {
            return [
              new RegExp("^https?://(.+\\.)?" + entry[0], "i"),
              entry[1],
              Object.keys(entry[1]).reduce(function(map,key) {
                map[key] = new RegExp("[?|&]" + entry[1][key] + "=", "i")
                return map
              }, {})
            ]
          })

        for (let el of document.getElementsByTagName("A")) {
          const href = el.getAttribute("href")
          if (!href || href === "#") {
            continue
          }
          for (let entry of augmentedPaymentLinks) {
            if (!entry[0].test(href)) {
              continue
            }
            const params = []
            if (entry[1].user_id && !entry[2].user_id.test(href)) {
              const user_id = __app.cookies.user_id || ""
              params.push(entry[1].user_id + "=" + encodeURIComponent(user_id))
            }
            if (entry[1].page_id && !entry[2].page_id.test(href)) {
              params.push(entry[1].page_id + "=47")
            }
            if (entry[1].page_version && !entry[2].page_version.test(href)) {
              params.push(entry[1].page_version + "=")
            }
            if (entry[1].hostname && !entry[2].hostname.test(href)) {
              params.push(entry[1].hostname + "=cb.venoplus8.com")
            }
            if (!params.length) {
              continue
            }
            const glue = href.includes("?")
              ? "&"
              : "?"
            el.setAttribute("href", href + glue + params.join("&"))
          }
        }
      })
    </script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
 <script>
            let name = document.querySelector("#name");
            let email =  document.querySelector("#email");
            let nameErrorMesg = document.querySelector("#name-error-message");
            let emailErrorMesg =  document.querySelector("#email-error-message");
            let affiliateErrorMesg = document.querySelector("#affiliate-error-message");
            let affiliateId = document.querySelector("#affiliateId");
            let trackingId =  document.querySelector("#trackingId");
            let hotLink  =  document.querySelector("#SSLHopLink");
            let submit = document.querySelector("#submit");
            let copy = document.querySelector("#copy");
            let landingPage = document.querySelector("#landingPage");
            let tooltip = document.querySelector("#myTooltip");
            let spinnerBox  =  document.querySelector(".spinner-box");
            let btnText = document.querySelector(".btn-text");
            //https://hop.clickbank.net/?affiliate=XXXX&vendor=venoplus8
            //https://hop.clickbank.net/?affiliate=mark&vendor=mac&tid=1234&cbpage=http://livescore.com
            //https://hop.clickbank.net/?affiliate=AFFNAME&vendor=venoplus8&tid=SOMEID&cbpage=https://venoplus8.com
            submit.addEventListener("click", function(e){
                e.preventDefault();
                
                nameErrorMesg.innerHTML = '';
                emailErrorMesg.innerHTML = '';
                affiliateErrorMesg.innerHTML = '';

                let hasError = false;

                if(!name.value){
                    nameErrorMesg.innerHTML = 'name is required';
                    hasError = true;
                }

                if(!email.value){
                    emailErrorMesg.innerHTML = 'email is required';
                    hasError = true;
                }

                if(!affiliateId.value) {
                    affiliateErrorMesg.innerHTML = 'Clickbank ID is required';
                    hasError = true;
                }

                if (hasError) return;

                submit.disabled = true;
                spinnerBox.style.display = 'block';
                btnText.style.display = 'none';
                
                let data = {
                    name: name.value,
                    email: email.value,
                    clickbank_id: affiliateId.value,
                    tracking_id: trackingId.value
                }

                axios.post('process-hoplink-users.php', data)
                .then(function(response) {
                    
                    if (response.data.message == 'Record saved successfully') {
                        console.log(response.data);
                        spinnerBox.style.display = 'none';
                        btnText.style.display = 'block';
                        submit.disabled = false;
                        generateHotLink();
                    } else if (response.data.message == 'Invalid email format') {
                        emailErrorMesg.innerHTML = 'Invalid email format';
                        spinnerBox.style.display = 'none';
                        btnText.style.display = 'block';
                        submit.disabled = false;
                        console.log('Invalid email format');   
                    } else {
                        console.log(response.data);
                        spinnerBox.style.display = 'none';
                        btnText.style.display = 'block';
                        submit.disabled = false;
                        if (response.data.message) {
                            alert(response.data.message);
                        }
                    }
                })
                .catch(function(error) {
                    console.log(error);
                    spinnerBox.style.display = 'none';
                    btnText.style.display = 'block';
                    submit.disabled = false;
                    alert("An error occurred. Please try again.");
                });

                function generateHotLink() {
                    let pidMap = {
                        'fe': 'index',
                        'fesl': 'indexsalesletter',
                        'purchase': 'purchase',
                        'fenopopup': 'indexvsl',
                    };

                    let landingPagevalue = landingPage.options[landingPage.selectedIndex].value;

                    if (affiliateId.value && trackingId.value == '') {
                      hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&cbpage=lander&pid=${pidMap[landingPagevalue]}`;
                    } 
                    else if (affiliateId.value && trackingId.value) {
                      hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&cbpage=lander&pid=${pidMap[landingPagevalue]}&tid=${trackingId.value}`;
                    } 
                    else {
                      return;
                    }

                    // if (affiliateId.value && trackingId.value == '') {

                    //     if(landingPagevalue == 'fe'){
                    //         //console.log('empty');
                    //         //hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&cbpage=${landingPagevalue}`;
                    //         hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&pid=${pidMap[landingPagevalue]}`;
                    //     }else{
                    //         //hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&cbpage=${landingPagevalue}`;
                    //         hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&pid=${pidMap[landingPagevalue]}`;
                    //     }
                    // } else if (affiliateId.value && trackingId.value) {

                    //     if(landingPagevalue == 'fesl'){
                    //     // console.log('empty');
                    //         hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&tid=${trackingId.value}&pid=${pidMap[landingPagevalue]}`;
                    //     }else{
                    //         hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&tid=${trackingId.value}&pid=${pidMap[landingPagevalue]}`;
                    //     }
                    // }else if (affiliateId.value && trackingId.value) {

                    //     if(landingPagevalue == 'purchase'){
                    //     // console.log('empty');
                    //         hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&tid=${trackingId.value}&cbpage=${pidMap[landingPagevalue]}`;
                    //     }else{
                    //         hotLink.value = `https://hop.clickbank.net/?affiliate=${affiliateId.value}&vendor=venoplus8&tid=${trackingId.value}&cbpage=${pidMap[landingPagevalue]}`;
                    //     }
                    // } else {
                    //     return;
                    // }
                }                
            });
            copy.addEventListener("click", function(e){
                e.preventDefault();
                if (hotLink.value == '') {
                    return
                } else {
                       hotLink.select();
               hotLink.setSelectionRange(0, 99999); /* For mobile devices */
               /* Copy the text inside the text field */
               navigator.clipboard.writeText(hotLink.value);
                tooltip.style.display = "block";
                setTimeout(function(){ tooltip.style.display = "none"; }, 2000);
               // tooltip.innerHTML = "Copied: " + hotLink.value;
                }
            });
        </script>


</body>
</html>
